package com.tvsmotor.controller;


import org.bson.types.ObjectId;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;

import com.tvsmotor.Entity.Production;
import com.tvsmotor.Service.ProductionDataService;
import com.tvsmotor.exception.InvalidDataException;
import com.tvsmotor.exception.ResourceNotFoundException;

import jakarta.validation.Valid;

import java.util.List;
import java.util.Optional;



@RestController
@RequestMapping("/api/productionData")
public class ProductionDataController {

    @Autowired
    private ProductionDataService productionDataService;

    // Create Production Data
    @PostMapping
    public Production createProductionData(@Validated @RequestBody Production productionData) {
        // Check if batchId is missing
       
    	
        return productionDataService.saveProductionData(productionData);
    }

    // Get All Production Data
    @GetMapping
    public List<Production> getAllProductionData() {
        return productionDataService.getAllProductionData();
    }

    // Get Production Data by Batch ID
    @GetMapping("/batch/{batchId}")
    public List<Production> getProductionDataByBatchId(@PathVariable int batchId) {
        List<Production> productions = productionDataService.getProductionDataByBatchId(batchId);

        if (productions.isEmpty()) {
            throw new ResourceNotFoundException("No production data found for batch ID: " + batchId);
        }

        return productions;
    }

    // Bulk Insert Production Data
    @PostMapping("/batch/bulkInsert")
    public List<Production> saveProductionData(@RequestBody List<Production> productions) {
        for (Production production : productions) {
          
            productionDataService.saveProductionData(production);
        }
        return productions;  // Return saved data
    }

    // Delete Production Data by Batch ID
    @DeleteMapping("/batch/{batchId}")
    public String deleteProductionData(@PathVariable int batchId) {
        List<Production> productions = productionDataService.getProductionDataByBatchId(batchId);
        if (productions.isEmpty()) {
            throw new ResourceNotFoundException("No production data found to delete for batch ID: " + batchId);
        }
        return productionDataService.deleteProductionData(batchId);
    }
    
    @PutMapping("/batch/{batchId}")
    public Production updateProductionData(@PathVariable int batchId, @Valid @RequestBody Production productionData) {
        // Ensure the batchId in the path matches the batchId in the body (if provided)
        if (productionData.getBatchId() != 0 && productionData.getBatchId() != batchId) {
            throw new InvalidDataException("Batch ID in the path and request body must match or be omitted in the body.");
        }
        return productionDataService.updateProductionData(batchId, productionData);
    }
}
