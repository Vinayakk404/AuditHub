package com.tvsmotor.Repository;

import java.util.List;

import org.bson.types.ObjectId;
import org.springframework.data.mongodb.repository.MongoRepository;

import com.tvsmotor.Entity.Production;

public interface ProductionRepository extends MongoRepository<Production, Integer> {
    List<Production> findByBatchId(int batchId);  // Example query method to find by batch ID
    public void deleteByBatchId(int batchId);
}
