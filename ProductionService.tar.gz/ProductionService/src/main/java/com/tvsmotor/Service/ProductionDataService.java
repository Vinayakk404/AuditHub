package com.tvsmotor.Service;



import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.tvsmotor.Entity.Production;
import com.tvsmotor.Repository.ProductionRepository;
import com.tvsmotor.exception.ResourceNotFoundException;

import java.util.List;



	@Service
	public class ProductionDataService implements ProductionDataServiceInterface {

	    @Autowired
	    private ProductionRepository productionDataRepository;

	    @Override
	    public Production saveProductionData(Production productionData) {
	    
	    	 
	              // Ensure provided batchId is unique
	              if (productionDataRepository.existsById(productionData.getBatchId())) {
	                  throw new IllegalArgumentException("Batch ID " + productionData.getBatchId() + " already exists.");
	              
	          }
	          return productionDataRepository.save(productionData);
	    }

	    @Override
	    public List<Production> getAllProductionData() {
	        return productionDataRepository.findAll();
	    }

	    @Override
	    public List<Production> getProductionDataByBatchId(int batchId) {
	        return productionDataRepository.findByBatchId(batchId);
	    }

	    @Override
	    public int getLastBatchId() {
	        List<Production> allProductionData = productionDataRepository.findAll();
	        if (allProductionData.isEmpty()) {
	            return 0;  // Starting batch ID
	        }
	        return allProductionData.stream()
	                .mapToInt(Production::getBatchId)
	                .max()
	                .orElse(0);
	    }

	    @Override
	    public String deleteProductionData(int batchId) {
	        List<Production> productions = getProductionDataByBatchId(batchId);
	        if (productions.isEmpty()) {
	            throw new ResourceNotFoundException("Batch ID not found: " + batchId);
	        }
	        productionDataRepository.deleteByBatchId(batchId);
	        return "Item deleted";
	    }

	    @Override
	    public Production updateProductionData(int batchId, Production productionData) {
	        // Fetch existing Production data
	        Production existingProduction = productionDataRepository.findById(batchId)
	                .orElseThrow(() -> new ResourceNotFoundException("No production data found for batch ID: " + batchId));

	        // Update fields (excluding batchId)
	        existingProduction.setVehicleModel(productionData.getVehicleModel());
	        existingProduction.setProductionLine(productionData.getProductionLine());
	        existingProduction.setShift(productionData.getShift());
	        existingProduction.setPlannedProductionUnits(productionData.getPlannedProductionUnits());
	        existingProduction.setActualProductionUnits(productionData.getActualProductionUnits());
	        existingProduction.setProductionStartTime(productionData.getProductionStartTime());
	        existingProduction.setProductionEndTime(productionData.getProductionEndTime());
	        existingProduction.setDelayInMinutes(productionData.getDelayInMinutes());
	        existingProduction.setStatus(productionData.getStatus());
	        existingProduction.setOperatorId(productionData.getOperatorId());
	        existingProduction.setVehicleId(productionData.getVehicleId());
	        existingProduction.setComments(productionData.getComments());
	        existingProduction.setAnomalyFlag(productionData.isAnomalyFlag());
	        existingProduction.setAnomalyType(productionData.getAnomalyType());

	        // Save the updated Production data
	        return productionDataRepository.save(existingProduction);
	}
	}

