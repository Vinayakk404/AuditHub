package com.tvsmotor.Service;


import java.util.List;

import java.util.Optional;

import com.tvsmotor.Entity.Production;



public interface ProductionDataServiceInterface {
    Production saveProductionData(Production productionData);
    List<Production> getAllProductionData();
    List<Production> getProductionDataByBatchId(int batchId);
    String deleteProductionData(int batchId);
    int getLastBatchId();
    Production updateProductionData(int batchId, Production productionData);

}
